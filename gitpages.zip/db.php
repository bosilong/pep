<?php
 header("Access-Control-Allow-Origin: *");
 $con = mysqli_connect("localhost","u651696251_projectpep","pass8Modise3","u651696251_project_db") or die ("could not connect database");
?>