	        <?php

            	$id = $_GET['package_id'];            
            	$data=array();	
            	$stmt=$db_con->prepare("SELECT * FROM tbl_beneficiaries, tbl_locations
            	where tbl_beneficiaries.location_id=tbl_locations.location_id AND package_id=:id");
            	$stmt->execute(array(':id'=>$id));

            	while($row=$stmt->fetch(PDO::FETCH_ASSOC))
            		{

 $data[]=$row;
}
echo json_encode($data);
?>