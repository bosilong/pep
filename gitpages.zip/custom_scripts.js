 

        $(document).ready(function() {
            var url = "http://botswanabusinessdirectory.org/json.php";
            $.getJSON(url, function(result) {
                console.log(result);
                $.each(result, function(i, field) {
                    var beneficiary_id = field.beneficiary_id;
                    var beneficiary = field.beneficiary;
                    var locationName = field.locationName;
                    var packageName = field.packageName;
                    var contactnum = field.contactnum;
$("#listofbeneficiaries").append("<a data-transition='slide' class='ui-btn ui-btn-icon-right ui-icon-carat-r' style='border-radius: 8px;' href='http://botswanabusinessdirectory.org/detailinfo.php?beneficiary_id=" + beneficiary_id + "&beneficiary=" + beneficiary + "'><div class='ui-responsive-panel'><img class='imgs' height='80' width='80' src='icon.png' style='margin-left:-18px;float: left;margin-right: 10px;'/></div><h3 style='text-transform:capitalize;text-align:left; font-size: 16px;margin-inline-start: 0px;margin-inline-end: 0px;'>" + beneficiary + " </h3><p style='text-transform:capitalize;font-size:unset;text-transform: capitalize;color:#000; text-align:left;color:#000;font-weight:normal;text-overflow:ellipsis;overflow:hidden;white-space:nowrap;margin-bottom: 1px;'>" + packageName + "</p><p style=' font-size: unset;text-transform: capitalize;color:#000; text-align:left;color:#000;font-weight:normal;text-overflow:ellipsis;overflow:hidden;white-space:nowrap;margin-bottom: 1px;'>" + locationName + "</p></a>");
                });
            });
        });



        $(document).ready(function() {
            var url = "http://botswanabusinessdirectory.org/packagesjson.php";
            $.getJSON(url, function(result) {
                console.log(result);
                $.each(result, function(i, field) {
                    var package_id = field.package_id;
                    var packageName = field.packageName;

$("#packages2").append("<a data-transition='slide' class='ui-btn ui-btn-icon-right ui-icon-carat-r' id='sector' style='border-radius: 8px;' href='http://botswanabusinessdirectory.org/package.php?package_id=" + package_id + "&package = " + packageName + "'><h3 style='text-align:left; font-weight: bold;font-size: 16px !important;padding-left: 6px !important;padding-bottom: 8px !important;'>" + packageName + "</h3></a>");
                });
            });
        });

        $(document).ready(function() {
            var url = "http://botswanabusinessdirectory.org/locationsjson.php";
            $.getJSON(url, function(result) {
                console.log(result);
                $.each(result, function(i, field) {
                    var location_id = field.location_id;
                    var locationName = field.locationName;

$("#locations2").append("<a data-transition='slide' class='ui-btn ui-btn-icon-right ui-icon-carat-r' style='border-radius: 8px;' href='http://botswanabusinessdirectory.org/location.php?location_id=" + location_id + "&location=" + locationName + "'><h3 style='text-align:left; font-weight: bold;font-size: 16px !important;padding-left: 6px !important;padding-bottom: 8px !important;'>" + locationName + " </h3></a>");
                });
            });
        });
    