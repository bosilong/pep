 <?php

include('dbconfig.php');

	$id = $_GET['package_id'];	
	$stmt=$db_con->prepare("SELECT * FROM tbl_packages where package_id=:id");
	$stmt->execute(array(':id'=>$id));	
    $row=$stmt->fetch(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html>
<head>
   
    <title>Package Details</title>
    <meta charset="utf-8" />
    <meta charset="utf-8" />
  <meta name="format-detection" content="telephone=yes"/>
  <meta name="msapplication-tap-highlight" content="no"/>
    <meta id="viewport" name="viewport" content="user-scalable=no, initial-scale=1, maximum-scale=1, minimum-scale=1, width=device-width, height=device-height" />

    <link rel="stylesheet" href="scripts/jqm/jquery.mobile-1.4.5.css"/>
      <link rel="stylesheet" href="lib/jquery/jquery.mobile.simultaneous-transitions-replace.css"/>
    <link rel="stylesheet" href="culture.css"/>
    <link rel="stylesheet" href="css/bootstrap.min.css"/>


</head>
    
    
<body style="background:#043f53;" id="mybody">

<!-- Start of Sector Implementation -->
    <!-- Start of Sector main page -->
<div data-role="page" id="sector" style="background:#FFF; height: auto;" data-dom-cache="true">
    	<div data-role="header" data-position="fixed">
        <div data-role="navbar" class="homeborder" data-theme="d">
            <ul>
                <li><a href="#companyfeeds" class="nav-border" data-icon="search" data-prefetch>Search</a></li>
                <li><a href="#"  data-icon="tag" class="ui-btn-active nav-border" data-prefetch>Sector</a></li>
                <li><a href="#location" class="nav-border"  data-icon="location" data-prefetch>Location</a></li>
            </ul>
        </div>
	</div><!-- /header -->
	<div data-role="content" style=" height: auto;">	
        <h4 style="text-align: center;"><?php echo $row['locationName']; ?></h4>
        <div data-role="content" id="listview" data-theme="d" style="height:auto;" class="ui-content" role="main">            
            <div id=status></div>
            <ul data-role="listview" data-filter="true" data-filter-placeholder="Search for Sectors..." data-inset="true" data-theme="d" style="color:black; text-shadow:none; ">

          <?php
            $id = $_GET['package_id'];	
        	$stmt=$db_con->prepare("SELECT * FROM tbl_beneficiaries, tbl_locations WHERE tbl_beneficiaries.location_id=tbl_locations.location_id AND package_id=:id");
        	$stmt->execute(array(':id'=>$id));	
			while($row=$stmt->fetch(PDO::FETCH_ASSOC))
			{
				?>  
       <a data-transition="slide" class="ui-btn ui-btn-icon-right ui-icon-carat-r" style="border-radius: 8px;" href='detailinfo.php?beneficiary_id=<?php echo $row['beneficiary_id']; ?>'>

    	<div class="ui-responsive-panel">
    	<img class="imgs" height="80" width="80" src="icon.png" style="margin-left:-18px;float: left;margin-right: 10px;">
    	</div>
    
    	<h3 style="text-transform:capitalize;text-align:left; font-size: 16px;margin-inline-start: 0px;margin-inline-end: 0px;"><?php echo $row['beneficiary']; ?></h3>
    
    	<p style="text-transform:capitalize;font-size:unset;text-transform: capitalize;color:#000; text-align:left;color:#000;font-weight:normal;text-overflow:ellipsis;overflow:hidden;white-space:nowrap;margin-bottom: 1px;"><?php echo $row['locationName']; ?></p>
 
        </a>
<?php } ?>
        </div>
    </div><!-- /content -->
	<div data-role="footer" class="adverts" data-position="fixed" data-theme="b" style="background-color:black;">
      <div data-role="navbar" id="ads"> <ul><li><div id="ad1" class="ad"><a href="#ceda" ><img src="images/ceda/ceda.png" height="50px" width="50px" style="border-radius: 40%;"></a></div></li> <li><div id="ad2" class="ad"> <a href="#BusinessSquareAd" ><img src="images/burs/burs.png" height="50px" width="50px" style="border-radius: 40%;"></a></div></li> <li><div id="ad3" class="ad"> <a href="#eBotswanaAd"  ><img src="images/burs/lea.png"  height="50px" width="50px" style="border-radius: 40%;"></a></div></li></ul></div>
	</div><!-- /footer -->
</div><!--End of sector main page --> 
   

    <script type="text/javascript" src="scripts/cordova/cordova.js"></script>
    <script type="text/javascript" src="scripts/js/index.js"></script>
    <script src="scripts/jqc/jquery.js"></script>
	<script srs="lib/jquery-1.11.3.js"></script>
	<script src="lib/jquery/jquery.mobile.simultaneous-transitions-replace.js"></script> 
    <script src="scripts/jqm/jquery.mobile-1.4.5.js"></script>
    <script src="geturi.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

</body>
</html>		