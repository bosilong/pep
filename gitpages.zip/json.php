<?php
include "db.php";
$data=array();
$q=mysqli_query($con,"SELECT * FROM tbl_beneficiaries, tbl_packages, tbl_locations
	         WHERE 
	         tbl_beneficiaries.package_id=tbl_packages.package_id AND 
	         tbl_beneficiaries.location_id=tbl_locations.location_id
	         ORDER BY beneficiary ASC");
while ($row=mysqli_fetch_object($q)){
 $data[]=$row;
}
echo json_encode($data);
?>