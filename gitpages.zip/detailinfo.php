 <?php

require_once('dbconfig.php');

	$id = $_GET['beneficiary_id'];	
	$stmt=$db_con->prepare("SELECT * FROM tbl_beneficiaries, tbl_locations, tbl_packages 
        WHERE 
            tbl_beneficiaries.location_id=tbl_locations.location_id AND 
            tbl_beneficiaries.package_id=tbl_packages.package_id AND beneficiary_id=:id");
	$stmt->execute(array(':id'=>$id));	
	$row=$stmt->fetch(PDO::FETCH_ASSOC);
$db_con = null; 	
?>

<!DOCTYPE html>
<html manifest="pep.appcache">
<head>
    <title>Beneficiary Details</title>
    <meta charset="utf-8" />
    <meta name="format-detection" content="telephone=yes"/>
    <meta name="msapplication-tap-highlight" content="no"/>
	<meta id="viewport" name="viewport" content="user-scalable=no, initial-scale=1, maximum-scale=1, minimum-scale=1, width=device-width, height=device-height" />

    <link rel="stylesheet" href="scripts/jqm/jquery.mobile-1.4.5.css"/>
	<link rel="stylesheet" href="lib/jquery/jquery.mobile.simultaneous-transitions-replace.css"/>
    <link rel="stylesheet" href="culture.css"/>
    
</head>
    
    
<body  style="background:#FFF;" id="mybody">
    <div data-role="page" id="detailinfo"  style="background: #FFF no-repeat center center fixed; height: auto;" data-dom-cache="true">
        
	    <div data-role="header" style="background-color: #043f53;">
	         <a href="#companyfeeds" class="ui-btn ui-btn-left ui-icon-carat-l ui-btn-icon-left ui-corner-all" data-iconshadow="true" data-theme="a" style=" color:black; background:none; border:none; width: 20px; height:30px; padding-right: 50px; text-shadow:none;"></a>
	        <h1 id="headertitle">Contact Details</h1>
	       
		    
	    </div><!-- /header -->
	    
	    <div data-role="content" style="height:100%;">	
            <div class="ui-content ui-body-d">
                <div class="ui-content ui-body-d" style="border: 1px solid #043f53; border-radius: 8px;">
                <h3 style="text-align:center;text-shadow:none; font-weight:bold;color:#043f53;"><?php echo $row['beneficiary']; ?></h3>
    <hr style="border-color: #043f53;">

                <h4 style="text-align:left;margin-top:16px;color: #043f53;">Call:</h4>
                
                <img height="30" width="30" src="callme.png" style="margin-right: 10px;"><a href="tel:<?php echo $row['contactnum']; ?>" style="padding:6px; border:1px solid #043f53;; background-color: transparent; color:#043f53;border-radius: 6px;text-decoration: none;" >+267 <?php echo $row['contactnum']; ?></a><br><br>

                <img height="30" width="30" src="callme2_burned.png" style="margin-right: 10px;"><a href="tel:<?php echo $row['contactnum1']; ?>" style="padding:6px; border:1px solid #043f53;; background-color: transparent; color:#043f53;border-radius: 6px;text-decoration: none;" >+267 <?php echo $row['contactnum1']; ?></a><br>
                
    <hr style="border-color: #043f53;">
                <h4 style="text-align:left;color: #043f53;">Product/Service:</h4>
                <h4 style="text-align:left;"><?php echo $row['packageName']; ?></h4>
    <hr style="border-color: #043f53;">
                <h4 style="text-align:left;color: #043f53;">Location:</h4>
                <p class="data3"><img class="data2" height="35" width="35" src="images/location.png"><?php echo $row['locationName']; ?></p>
                </div>
            </div>
             <div data-role="footer" class="adverts" data-position="fixed" data-theme="b" style="background-color:black;">
      <div data-role="navbar" id="ads"> <ul><li><div id="ad1" class="ad"><a href="#ceda" ><img src="images/ceda/ceda.png" height="50px" width="50px" style="border-radius: 40%;"></a></div></li> <li><div id="ad2" class="ad"> <a href="#burs" ><img src="images/burs/burs.png" height="50px" width="50px" style="border-radius: 40%;"></a></div></li> <li><div id="ad3" class="ad"> <a href="#lea"  ><img src="images/burs/lea.png"  height="50px" width="50px" style="border-radius: 40%;"></a></div></li></ul></div>
	</div>
	    </div><!-- /content -->
	   
       
    </div><!-- /.End of page --> 

    <script type="text/javascript" src="scripts/cordova/cordova.js"></script>
    <script type="text/javascript" src="scripts/js/index.js"></script>
    <script src="scripts/jqc/jquery.js"></script>
	<script srs="lib/jquery-1.11.3.js"></script>
	<script src="lib/jquery/jquery.mobile.simultaneous-transitions-replace.js"></script> 
    <script src="scripts/jqm/jquery.mobile-1.4.5.js"></script>
    <script src="geturi.js"></script>
    
</body>
</html>